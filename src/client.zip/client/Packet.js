function Packet() {
	this.up = false;
	this.down = false;
	this.left = false;
	this.right = false;
}