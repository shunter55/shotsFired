function Packet() {
	this.up = false;
	this.down = false;
	this.left = false;
	this.right = false;
	this.shoot = false;
	this.shootPos = {'x': 0, 'y': 0};
}